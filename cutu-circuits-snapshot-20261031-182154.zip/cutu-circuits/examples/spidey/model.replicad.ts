import {
  makeBox,
  makeCylinder,
  makeEllipsoid,
  makeCompound,
  makeCircle,
  makeLine,
  makeBezierCurve,
  assembleWire,
  genericSweep,
} from "replicad";

// Photo-informed reconstruction in millimetres, Z up. Dimensions are estimates,
// scaled from a nominal 23 × 12 × 29 mm SG90. See docs/model-reference.md.
// Exactly three actuators: each side drives its front/hind wire pair; the
// horizontal centre shaft tilts both middle legs. Electronics are external.
export const defaultParams = {
  wireRadius: 0.55,
  bodyWidth: 38,
  bodyHeight: 43,
  legSpan: 246,
  stanceLength: 206,
  kneeHeight: 109,
};

export default function main(p) {
  const result = [];
  const halfSpacing = (p.bodyWidth - 12) / 2;
  const base = p.bodyHeight;
  const add = (name, shape, color, opacity = 1) =>
    result.push({ name, shape, color, opacity });
  // A circular profile swept along a real OCCT wire; bends retain straight
  // steel runs instead of a Catmull-Rom approximation or floating cylinders.
  const pipe = (pts, radius, smooth = false) => {
    const tangent = pts[1].map((v, i) => v - pts[0][i]);
    const spine = assembleWire(
      smooth
        ? [makeBezierCurve(pts)]
        : pts.slice(1).map((pt, i) => makeLine(pts[i], pt)),
    );
    return genericSweep(
      assembleWire([makeCircle(radius, pts[0], tangent)]),
      spine,
      { transitionMode: "round" },
    );
  };
  const mount = (shape, side) =>
    side === 0
      ? shape.rotate(90, [0, 0, 0], [1, 0, 0]).translate([0, 5, base + 12])
      : shape.translate([side * halfSpacing, 0, base]);
  const localHorn = () => {
    let h = makeBox([-11.5, -2, 29], [11.5, 2, 30.5])
      .fuse(makeBox([-2, -10, 29], [2, 10, 30.5]))
      .fuse(makeCylinder(3.1, 2.3, [0, 0, 28.8]));
    for (const pt of [
      [8, 0],
      [-8, 0],
      [0, 7],
      [0, -7],
    ])
      h = h.cut(makeCylinder(0.65, 3, [pt[0], pt[1], 28.5]));
    return h;
  };
  for (const [label, side] of [
    ["left", -1],
    ["right", 1],
    ["tilt", 0],
  ]) {
    // Three stepped blue mouldings, seam ledges and a round output bearing.
    const shell = makeCompound([
      makeBox([-6, -11.5, 0], [6, 11.5, 3]),
      makeBox([-5.8, -11.3, 3.25], [5.8, 11.3, 22.7]),
      makeBox([-6, -11.5, 23], [6, 11.5, 25.5]),
      makeCylinder(5.3, 2, [0, 5.5, 25.5]),
      makeCylinder(2.5, 1.4, [0, 5.5, 27.5]),
      // Small remaining moulded tabs; the photographed build has no platform.
      makeBox([-4, -13.2, 2], [4, -11.5, 3.5]),
      makeBox([-4, 11.5, 2], [4, 13.2, 3.5]),
    ]);
    add(`servo-${label}`, mount(shell, side), "#184fc1", 0.96);
    const lid = makeCompound([
      makeBox([-5.7, -11.2, 22.7], [5.7, 11.2, 23]),
      makeBox([-5.7, -11.2, 3], [5.7, 11.2, 3.25]),
      makeCylinder(3, 0.8, [0, 5.5, 28.4]),
    ]);
    add(`servo-${label}-seams`, mount(lid, side), "#103887");
    let horn = localHorn();
    if (side) horn = horn.rotate(side * 45, [0, 0, 0], [0, 0, 1]);
    horn = horn.translate([0, 5.5, 0]);
    add(`horn-${label}`, mount(horn, side), "#f1efdf");
    const screw = makeCylinder(1.35, 0.7, [0, 5.5, 30.8]).cut(
      makeBox([-0.25, 4.2, 31.1], [0.25, 6.8, 31.6]),
    );
    add(`horn-${label}-screw`, mount(screw, side), "#b3b5b2");
    const glue = makeCompound([
      makeEllipsoid(5.6, 3.2, 1.6).translate([0, 5.5, 32]),
      makeEllipsoid(3.7, 2.7, 1.5).translate([4.4, 6.8, 31.7]),
      makeEllipsoid(2.7, 3, 1.8).translate([-4.2, 4.7, 31.8]),
      makeEllipsoid(1.9, 2, 1.2).translate([7, 6.4, 31.4]),
    ]);
    add(`glue-${label}`, mount(glue, side), "#e3eced", 0.6);
  }
  for (const [label, side] of [
    ["left", -1],
    ["right", 1],
  ]) {
    const x = side * halfSpacing;
    for (const [index, fore] of [
      [1, -1],
      [3, 1],
    ]) {
      const pts = [
        [x, 5.5, base + 32],
        [x + side * 13, 5.5 + fore * 11, base + 32],
        [side * 42, fore * 26, p.kneeHeight - 15],
        [side * 56, fore * 43, p.kneeHeight],
        [side * (p.legSpan / 2 - 10), (fore * p.stanceLength) / 2, 1.2],
      ];
      const id = `leg-${label}-${index}`;
      add(id, pipe(pts, p.wireRadius), "#b9c6d0");
      add(
        `foot-${label}-${index}`,
        makeEllipsoid(1.3, 1.7, 1.1).translate(pts[pts.length - 1]),
        "#d2e0e3",
        0.65,
      );
    }
    const pts = [
      [0, -27.2, base + 17.5],
      [side * 28, -27.2, base + 16.2],
      [side * 35, -24, base + 18],
      [side * 59, -8, p.kneeHeight - 18],
      [(side * p.legSpan) / 2, 1, 1.2],
    ];
    add(`leg-${label}-2`, pipe(pts, p.wireRadius), "#b9c6d0");
    add(
      `foot-${label}-2`,
      makeEllipsoid(1.3, 1.7, 1.1).translate(pts[pts.length - 1]),
      "#d2e0e3",
      0.65,
    );
  }
  // External loose servo ribbons, three individually coloured conductors each.
  // Endpoints suggest the off-board harness without inventing an onboard MCU.
  for (const [i, label] of ["left", "tilt", "right"].entries()) {
    const x = (i - 1) * halfSpacing;
    for (const [n, color] of ["#8a492b", "#d44428", "#ed922f"].entries()) {
      const pts = [
        [x + (n - 1) * 1.05, 10, base + 3],
        [x + (n - 1) * 1.05, 37, base - 6],
        [26 + (n - 1) * 1.05, 47 + i * 6, base + 90 - i * 12],
        [55 + i * 8 + (n - 1) * 1.05, 26 + i * 10, base - 33],
        [74 + i * 10 + (n - 1) * 1.05, 40 + i * 9, 4 + i],
      ];
      add(`cable-${label}-${n}`, pipe(pts, 0.48, true), color);
    }
    add(
      `plug-${label}`,
      makeBox(
        [71 + i * 10, 37 + i * 9, 3 + i],
        [77 + i * 10, 44 + i * 9, 6 + i],
      ),
      "#282d31",
    );
  }
  // Small hot-glue seam binding cases, not a fabricated chassis.
  add(
    "body",
    makeCompound([
      makeEllipsoid(1.2, 8, 2).translate([-6.5, -5, base + 15]),
      makeEllipsoid(1.2, 8, 2).translate([6.5, -5, base + 15]),
    ]),
    "#dbe6e8",
    0.55,
  );
  return result;
}
