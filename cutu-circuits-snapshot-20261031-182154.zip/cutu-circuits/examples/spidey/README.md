# Spidey — three servos, six wire legs

Compact Beetle/Ringo-style assembly. Dimensions, horn alignment and pulse-to-angle
mapping are illustrative and unmeasured. GPIO and gait commands come from the real
ESP8266 firmware. The last-known calibration profile is unverified. Only forward
walking is implemented; rightward drift remains unresolved. There is no measured
shaft position feedback. A preview shows commanded pulses, never actual leg pose.

## Local programs

Inspect hardware and Preview gait run offline. Connect keeps one authenticated TCP
session alive, reports real device status and DIAG commanded pulses, and stops after
the requested duration or cancellation. Status takes a short snapshot. Walk executes
a bounded forward queue with live heartbeat; cancellation sends STOP using that same
connection before closing. Only one capability per project may run at a time. Use the generic live-operation send tool to send JSONL controls to
the existing monitor: `{"type":"status"}`, `{"type":"walk","steps":1,"speed":100,"durationSeconds":30}`,
or `{"type":"stop"}`. These reuse its sole connection; input validation happens
in the saved program. Cancel exits the session and sends STOP. Do not run upstream
CLI tools in parallel.

Create an untracked `.local/wifi.json` in your project, containing your local board's
`host` and `token` fields (optional `port`, default 8266). Alternatively set the
`SPIDEY_CONFIG` environment variable to a private file. Do not put credentials in the
project manifest, inputs, or source. Python 3 is required; this TCP program uses only
the standard library. Host networking must be on the board's private Wi-Fi network.
No physical device was connected during development.

STOP detaches servos and the robot needs physical support. The firmware also stops
when its 3 second heartbeat expires. A process being killed cannot guarantee an
acknowledged STOP during a network outage: inspect the actual board before use.

## Wiring and firmware

D5/GPIO14 → left servo; D6/GPIO12 → right servo; D7/GPIO13 → tilt servo.
BEC regulated 5 V supplies servo power; its ground MUST connect to NodeMCU ground.
USB powers the NodeMCU. Do not connect servo 5 V to GPIO or the LiPo to the MCU.
`firmware/src/main.cpp` is the actual upstream hexapod firmware. To build, privately
create `firmware/include/secrets.h` from the example and use PlatformIO in firmware/.
Native circuit source describes connectivity; it is not a production PCB layout.

## Provenance

Firmware, portable client, onboarding walk helper, hexapod README and calibration
profile copied from https://github.com/Rtx09x/cutie-circuits-spidey at commit
866e3d69e3a174723bb67af50babb4ab2d388da7. Full relevant native source is included;
upstream files retain their notices. The repository supplied no standalone license;
reuse is under the project owner's authorization, with no new license claim.
`programs/spidey.py` adapts the upstream protocol and heartbeat handling for a local
JSONL operation session. Original clients are retained under upstream/tools/.
The firmware PlatformIO include path is adjusted to this standalone directory.
