"""Cutu Circuits Spidey adapter. One process owns one authenticated TCP session.
Adapted from Rtx09x/cutie-circuits-spidey tools/hexapod.py and onboard_walk.py.
Credentials stay in SPIDEY_CONFIG or .local/wifi.json; they are never telemetry.
"""
import json
import os
import queue
from pathlib import Path
import signal
import socket
import sys
import threading
import time

stopping = False
controls_queue = queue.Queue(maxsize=32)

def stop_requested(*_):
    global stopping
    stopping = True

signal.signal(signal.SIGTERM, stop_requested)
signal.signal(signal.SIGINT, stop_requested)

def emit(**data):
    print(json.dumps(data), flush=True)

class Session:
    def __init__(self, config):
        self.sock = socket.create_connection((config['host'], int(config.get('port', 8266))), timeout=3)
        self.sock.settimeout(.2)
        self.buffer = b''
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        reply = self.command('AUTH ' + config['token'])
        if reply != 'OK AUTH':
            raise RuntimeError('Device authentication failed')

    def command(self, command, cleanup=False):
        if stopping and not cleanup:
            raise InterruptedError('Stop requested')
        self.sock.sendall((command + '\n').encode('ascii'))
        deadline = time.monotonic() + 1
        while time.monotonic() < deadline:
            if b'\n' not in self.buffer:
                try:
                    chunk = self.sock.recv(4096)
                except socket.timeout:
                    continue
                if not chunk:
                    raise ConnectionError('Device disconnected')
                self.buffer += chunk
                if len(self.buffer) > 65536:
                    raise RuntimeError('Device reply exceeds limit')
                continue
            line, self.buffer = self.buffer.split(b'\n', 1)
            reply = line.decode('ascii').strip()
            if reply == 'DONE':
                emit(source='device', event='queue-completed')
                continue
            if cleanup and reply != 'OK STOP':
                continue
            if reply.startswith('ERR'):
                raise RuntimeError('Device rejected command: ' + reply[:100])
            return reply
        raise TimeoutError('Device reply timed out')

    def status(self):
        reply = self.command('STATUS')
        if not reply.startswith('STATUS '):
            raise RuntimeError('Unexpected status reply')
        fields = {}
        for item in reply.split()[1:]:
            if '=' in item:
                key, value = item.split('=', 1)
                if key != 'ip':
                    fields[key] = int(value) if value.lstrip('-').isdigit() else value
        diag = self.command('DIAG')
        pulse_field = next((x.split('=', 1)[1] for x in diag.split() if x.startswith('commanded=')), '')
        pulses = [int(x) for x in pulse_field.split(',')] if pulse_field else []
        emit(source='device', state=fields, commandedPulseUs=dict(zip(['servo-left', 'servo-right', 'servo-tilt'], pulses)), shaftPosition='unmeasured')
        return fields

    def close(self):
        try:
            self.command('STOP', cleanup=True)
            emit(source='device', event='stop-acknowledged')
        finally:
            self.sock.close()

def preview(inputs):
    profile = json.loads(Path('profiles/spidey-last-known.json').read_text())
    centers = [j['center'] for j in profile['joints']]
    targets = [(2, 1645), (1, 1740), (2, 1505), (0, 1600), (2, 1345), (0, 1260), (2, 1505), (1, 1350)]
    for phase, (joint, pulse) in enumerate(targets):
        centers[joint] = pulse
        emit(source='offline-preview', calibrated=False, phase=phase, commandedPulseUs=dict(zip(['servo-left', 'servo-right', 'servo-tilt'], centers)), note='Illustrative kinematics; last-known profile, not measured position')
        if stopping:
            break
        time.sleep(float(inputs.get('phaseMs', 150)) / 1000)

def main():
    inputs = json.loads(sys.stdin.readline() or '{}')
    def controls():
        for line in sys.stdin:
            try:
                message = json.loads(line)
                if message.get('type') == 'cancel':
                    stop_requested()
                else:
                    controls_queue.put_nowait(message)
            except (ValueError, AttributeError, queue.Full):
                emit(source='adapter', error='Invalid control record or control queue full')
    threading.Thread(target=controls, daemon=True).start()
    action = sys.argv[1] if len(sys.argv) > 1 else 'inspect'
    if action == 'inspect':
        emit(source='project-files', controller='NodeMCU ESP8266', protocol='authenticated ASCII TCP / 8266', pins={'servo-left': 14, 'servo-right': 12, 'servo-tilt': 13}, feedback='No measured shaft position', calibration=json.loads(Path('profiles/spidey-last-known.json').read_text()))
        return
    if action == 'preview':
        preview(inputs)
        return
    path = Path(os.environ.get('SPIDEY_CONFIG', '.local/wifi.json')).expanduser()
    if not path.is_file():
        raise RuntimeError('Local credentials missing. Create .local/wifi.json with host and token, or set SPIDEY_CONFIG. See README.md.')
    config = json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(config.get('host'), str) or not isinstance(config.get('token'), str) or any(c in config['token'] for c in '\r\n'):
        raise RuntimeError('Local credential file requires a host and single-line token')
    session = Session(config)
    try:
        emit(source='device', event='authenticated', transport='tcp')
        if action == 'status':
            session.status()
            return
        def start_walk(request):
            for key, minimum, maximum in [('steps', 1, 20), ('speed', 1, 100), ('durationSeconds', 1, 300)]:
                value = request.get(key)
                if type(value) is not int or not minimum <= value <= maximum:
                    raise ValueError('Walk control requires steps 1–20, speed 1–100 and durationSeconds 1–300')
            session.command('STOP')
            session.command('CLEAR')
            session.command(f"ADD 100 100 {request['steps']} {request['speed']}")
            for joint in (1, 2, 3):
                session.command(f'ENABLE {joint}')
                time.sleep(.6)
                session.command('PING')
            session.command('RUN')
            emit(source='device', event='walk-started', steps=request['steps'], speed=request['speed'])
            return time.monotonic() + request['durationSeconds']

        walking = action == 'walk'
        walk_deadline = start_walk(inputs) if walking else None
        deadline = time.monotonic() + float(inputs.get('durationSeconds', 300))
        while not stopping and time.monotonic() < deadline:
            try:
                message = controls_queue.get_nowait()
            except queue.Empty:
                message = None
            if message:
                kind = message.get('type')
                if kind == 'walk':
                    try:
                        if walking:
                            raise ValueError('A walk is already running; send stop first')
                        walk_deadline = start_walk(message)
                        walking = True
                    except ValueError as error:
                        emit(source='adapter', error=str(error))
                elif kind == 'stop':
                    session.command('STOP')
                    walking = False
                    emit(source='device', event='stop-acknowledged')
                elif kind != 'status':
                    emit(source='adapter', error='Unknown control type; use status, walk, stop or cancel')
            state = session.status()  # STATUS is the firmware heartbeat.
            if walking and state.get('running') == 0:
                if state.get('action') != 1:
                    raise RuntimeError('Device stopped before completing the queue')
                walking = False
                emit(source='device', event='walk-completed')
                if action == 'walk':
                    return
            if walking and walk_deadline is not None and time.monotonic() >= walk_deadline:
                session.command('STOP')
                walking = False
                emit(source='device', event='walk-timeout-stopped')
                if action == 'walk':
                    raise TimeoutError('Walk duration exceeded; stopping device')
            time.sleep(.1 if not controls_queue.empty() else .5)
        if not stopping and action == 'walk' and walking:
            raise TimeoutError('Walk duration exceeded; stopping device')
    finally:
        session.close()  # STOP uses the sole existing connection, including cancellation.

if __name__ == '__main__':
    try:
        main()
    except InterruptedError:
        pass
    except Exception as error:
        # Never include connection/config exception details or authentication material.
        message = str(error) if isinstance(error, (RuntimeError, TimeoutError)) else type(error).__name__ + ': local device connection failed'
        emit(source='adapter', error=message)
        sys.exit(1)
