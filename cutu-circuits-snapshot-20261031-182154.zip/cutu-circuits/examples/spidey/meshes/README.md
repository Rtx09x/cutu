# Spidey native visual meshes

These 40 binary STL files contain the actual 68,360-triangle OpenCascade mesh buffers compiled from the default parameters of `../model.replicad.ts`. Source SHA-256 at extraction: `dc82f012fc06a65eb6e04a89990166ffdcc83845d9da011dfbf89a981612a069`.

The source photograph informed the native CAD reconstruction; these are not scanned or measured meshes. Each vertex was converted from millimetres to metres and translated into its link's local pivot frame for `../spidey.urdf`. Names, individual shape topology, colors and opacities are preserved through the URDF visual elements. Total binary mesh size is 3,421,360 bytes. Native CAD remains the editable mechanical source; recompile and regenerate these meshes when changing that source.

The URDF's collision geometry uses separate estimated cylinders/spheres/boxes, rather than treating thin-wire visuals as rigid filled convex hulls. Masses, inertia, collision dimensions and joint angle limits are engineering estimates. Wire/glue compliance, servo transmission backlash and pulse-to-angle calibration are not modeled. This supports inspectable articulation and real rigid-body contacts, not a validated walking prediction or measured hardware feedback.
