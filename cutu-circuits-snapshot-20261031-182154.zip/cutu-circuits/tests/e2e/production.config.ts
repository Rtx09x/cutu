import { defineConfig } from "@playwright/test";
import path from "node:path";
import shared from "../../playwright.config";

/** Verify the built UI and runtime together, without development HMR. */
export default defineConfig({
  ...shared,
  testDir: path.resolve("tests/e2e"),
  outputDir: path.resolve("artifacts/e2e-production"),
  reporter: [
    ["list"],
    [
      "html",
      {
        outputFolder: path.resolve("artifacts/e2e-production-report"),
        open: "never",
      },
    ],
  ],
  use: { ...shared.use, baseURL: "http://127.0.0.1:4310" },
  webServer: [],
});
