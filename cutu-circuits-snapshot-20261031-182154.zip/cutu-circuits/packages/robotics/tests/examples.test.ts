import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { createRobotSimulation, parseUrdf } from "../src/index.js";
import { stlVertices } from "../src/stl.js";
const example = (path: string) =>
  new URL(`../../../examples/${path}`, import.meta.url);
test("native arm example motors, gravity and bounded extension run through real physics", async () => {
  const model = parseUrdf(await readFile(example("robot/arm.urdf"), "utf8"));
  const sim = await createRobotSimulation(model, { fixedBase: true });
  try {
    sim.setJointTarget("shoulder", 0.6);
    sim.setJointTarget("extension", 1);
    const state = sim.step(1200);
    assert.equal(state.joints.extension.target, 0.16);
    assert.ok(Math.abs(state.joints.shoulder.position - 0.6) < 0.1);
    assert.ok(
      state.joints.extension.position > 0.14 &&
        state.joints.extension.position < 0.165,
    );
    for (const t of Object.values(state.links))
      assert.ok(t.position.every(Number.isFinite));
  } finally {
    sim.dispose();
  }
});
test("Spidey uses authored native visual meshes and estimated real collision dynamics", async () => {
  const model = parseUrdf(
    await readFile(example("spidey/spidey.urdf"), "utf8"),
  );
  assert.equal(model.links.length, 4);
  assert.equal(model.joints.length, 3);
  assert.ok(model.diagnostics.some((x) => x.code === "model-assumptions"));
  let triangles = 0;
  for (const l of model.links)
    for (const visual of l.visuals) {
      assert.equal(visual.geometry.type, "mesh");
      if (visual.geometry.type === "mesh") {
        const data = await readFile(
          example(`spidey/${visual.geometry.filename}`),
        );
        triangles +=
          stlVertices(
            data.buffer.slice(
              data.byteOffset,
              data.byteOffset + data.byteLength,
            ),
          ).length / 9;
      }
    }
  assert.equal(triangles, 68360);
  const sim = await createRobotSimulation(model, { fixedBase: false });
  try {
    const initial = sim.snapshot();
    const state = sim.step(600);
    assert.ok(state.contacts > 0);
    assert.notDeepEqual(state.links.body.position, initial.links.body.position);
    for (const t of Object.values(state.links))
      assert.ok(t.position.every((n) => Number.isFinite(n) && Math.abs(n) < 1));
  } finally {
    sim.dispose();
  }
});
