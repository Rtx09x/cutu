import type {ButtonHTMLAttributes, HTMLAttributes, KeyboardEvent, MouseEventHandler, ReactNode} from "react";
import {cn} from "@cutucircuits/ui/cn";

export type ButtonVariant = "bare" | "filled" | "ghost" | "primary";
export type ButtonSize = "lg" | "md" | "none" | "sm";
export type ButtonShape = "default" | "icon";

const variantClasses: Record<ButtonVariant, string> = {
  bare: "cursor-pointer disabled:cursor-default disabled:opacity-50",
  filled:
    "cursor-pointer rounded-xl bg-overlay-pressed text-ink corner-superellipse/1.3 hover:bg-overlay-strong hover:text-ink-strong disabled:cursor-default disabled:opacity-50 disabled:hover:bg-overlay-pressed disabled:hover:text-ink",
  ghost: "cursor-pointer text-ink-muted hover:text-ink-strong disabled:cursor-default disabled:opacity-50 disabled:hover:text-ink-muted [&_svg]:text-current",
  primary:
    "cursor-pointer rounded-xl text-ink corner-superellipse/1.3 hover:bg-overlay-hover hover:text-ink-strong disabled:cursor-default disabled:opacity-50 disabled:hover:bg-transparent disabled:hover:text-current",
};

const defaultSizeClasses: Record<ButtonSize, string> = {
  lg: "flex w-full items-center gap-3 px-3 py-2 text-left text-base",
  md: "flex w-full items-center gap-2.5 px-2.5 py-2 text-left text-sm",
  none: "",
  sm: "flex w-full items-center gap-2.5 px-2 py-1.5 text-left text-sm",
};

const iconSizeClasses: Record<ButtonSize, string> = {
  lg: "grid size-10 place-items-center",
  md: "grid size-9 place-items-center",
  none: "",
  sm: "grid size-6 place-items-center",
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  readonly as?: "button" | "div";
  readonly children: ReactNode;
  readonly shape?: ButtonShape;
  readonly size?: ButtonSize;
  readonly variant?: ButtonVariant;
}

export default function Button(props: ButtonProps) {
  const {as = "button", children, className, onClick, onKeyDown, shape = "default", size = "none", type = "button", variant = "bare", ...buttonProps} = props;
  const resolvedClassName = cn(variantClasses[variant], shape === "icon" ? iconSizeClasses[size] : defaultSizeClasses[size], className);

  if (as === "div") {
    const {disabled, tabIndex, ...divProps} = buttonProps;
    const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>): void => {
      if (disabled) return;
      onKeyDown?.(event as unknown as KeyboardEvent<HTMLButtonElement>);

      if (event.defaultPrevented || event.target !== event.currentTarget || (event.key !== "Enter" && event.key !== " ")) {
        return;
      }

      event.preventDefault();
      event.currentTarget.click();
    };

    return (
      <div
        {...(divProps as HTMLAttributes<HTMLDivElement>)}
        aria-disabled={disabled || divProps["aria-disabled"]}
        className={cn(resolvedClassName, disabled && "cursor-default opacity-50")}
        data-disabled={disabled || undefined}
        onClick={disabled ? undefined : (onClick as unknown as MouseEventHandler<HTMLDivElement>)}
        onKeyDown={handleKeyDown}
        role="button"
        tabIndex={disabled ? -1 : (tabIndex ?? 0)}
      >
        {children}
      </div>
    );
  }

  return (
    <button className={resolvedClassName} onClick={onClick} onKeyDown={onKeyDown} type={type} {...buttonProps}>
      {children}
    </button>
  );
}
