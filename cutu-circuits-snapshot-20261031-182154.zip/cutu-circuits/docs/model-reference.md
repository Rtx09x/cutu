# Spidey model reference

The assembly in `examples/spidey/model.replicad.ts` is a photo-informed reconstruction of Rudra's physical Spidey, not a dimensioned scan. The supplied photograph is the primary appearance reference. It shows a compact bonded cluster of three blue micro servos, white plastic cross horns, irregular translucent hot-glue bonds, six long bent steel-wire legs and loose orange/red/brown leads. There is no broad platform or stacked controller in that photograph. The ESP8266 and regulated servo supply remain in the electrical project graph as external components; their positions have not been measured and they have no assembly mesh.

## Primary construction reference

DmitryDzz, [Robot Beetle Ringo](https://www.instructables.com/Beetle-Ringo/), published 2014-02-24; inspected 2026-10-31. Full article text and image attachment URLs were read from the site's [article JSON](https://www.instructables.com/json-api/showInstructableModel?urlString=Beetle-Ringo).

- [Step 4: Beetles Tripod Gait](https://www.instructables.com/Beetle-Ringo/#step4) explicitly places **three servos in a row from left to right**. The left servo drives the left front/hind legs as one bent-wire part, the right servo does the same on the right, and the central servo tilts the two middle legs. This determines the three joints and coupled entities in the project graph.
- [Step 7: Assembling](https://www.instructables.com/Beetle-Ringo/#step7) directs the center output shaft horizontally, the side shafts upwards, the center cross horn horizontally and the side horns at 45 degrees. It specifies screws and trimming interfering inner horn arms. The model uses the corresponding shaft directions and white cross horns; trimming and precise spline indexing remain estimates.
- [Step 8: Making Legs](https://www.instructables.com/Beetle-Ringo/#step8) describes identical left/right front-hind wire parts, a separate center-leg stencil, correcting the center legs in plan to avoid collisions, hot-gluing the wires to the horns, and adding glue drops at the feet. The [marked side-leg photograph](https://content.instructables.com/FNO/187E/HS18BDE8/FNO187EHS18BDE8.jpg) was downloaded and visually inspected. Its raised angular knees, straight runs and connected front/hind shape support the construction used here.
- The article provides [side-leg stencil PDF](https://content.instructables.com/F8C/0OFI/HS18BDEO/F8C0OFIHS18BDEO.pdf) and [middle-leg stencil PDF](https://content.instructables.com/FL8/BVKG/HS18BDCK/FL8BVKGHS18BDCK.pdf). The direct endpoints returned empty bodies in this environment. Their existence and role are established by the article, but no dimensions were read from them.

The guide's original battery-holder chassis, Arduino Uno, IR receiver and tiny breadboard are not transferred into Rudra's assembly: his photograph and verified ESP8266 firmware take precedence.

## Estimated scale and parameters

A nominal SG90-sized case, approximately **23 × 12 × 29 mm**, anchors the scale. These dimensions identify a useful engineering envelope, not the exact servo manufacturer's drawing. All remaining placement is estimated from the photograph's proportions and perspective.

| Feature | Default estimate |
| --- | --- |
| Main blue cases | 23 × 12 × 29 mm nominal envelope, stepped lids/bearing included |
| Side-servo centers | 26 mm apart |
| Case bottom above ground | 43 mm |
| Side horn wire attachment | about 75 mm above ground |
| High side-wire knees | 109 mm above ground |
| Full foot span | 246 mm nominal, 248.6 mm with wire/foot radius |
| Front-to-hind foot stance | 206 mm nominal, 209.4 mm including glue feet |
| Steel-wire radius | 0.55 mm |

`wireRadius`, `bodyWidth`, `bodyHeight`, `legSpan`, `stanceLength` and `kneeHeight` change native solid geometry. The render uses the native kernel mesh buffers. Steel legs are circular profiles swept along angular OCCT wire paths; lead wires use smooth Bézier spines. Case mouldings, seams, horns, screws, glue bonds and feet are separate stable named shapes. Glue ellipsoids approximate the visible irregular blobs. Servo interiors, exact mould tooling, wire springback, glue deformation and connector pin details have not been measured or reverse-engineered.

The three output pivots are explicit `metadata.jointPivot` points on the servo entities. Servo bodies stay fixed while each joint rotates its horn, screw, glue, coupled legs and feet. The middle axis is horizontal along Y. Existing GPIO identities and pulse limits remain unchanged. The preview shows commanded pulse-derived angles only; no measured shaft feedback or validated walking dynamics is implied. Geometry parameter changes that move an output pivot require updating the corresponding authored graph pivot before interpreting a gait preview.

## Validation evidence

The actual OpenCascade worker compiled the source successfully into **40 named shapes**, **68,360 triangles**, and bounds approximately **248.60 × 209.40 × 109.45 mm**. Exports succeeded through the existing native engine: STEP 2,630,278 bytes, STL 17,295,096 bytes, OBJ 7,311,425 bytes. TypeScript application checking passed after the renderer change.

The existing printability analysis reports this multipart assembly as non-watertight and without a substantial flat print base, along with steep overhangs and an unset nozzle diameter. This reconstruction is an inspectable assembly/CAD reference; its compile and export checks do not establish a ready-to-print monolithic part.
