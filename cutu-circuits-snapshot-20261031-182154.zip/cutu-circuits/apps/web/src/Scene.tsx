import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import type { Project, CadResult, Entity } from "@cutucircuits/core";
import type { ProgramMotion } from "./programMotion";
interface Props {
  project: Project;
  selected: string | null;
  onSelect: (id: string | null) => void;
  playing: boolean;
  phase: number;
  cad?: CadResult;
  reset: number;
  program?: ProgramMotion;
}
export function Scene({
  project,
  selected,
  onSelect,
  playing,
  phase,
  cad,
  reset,
  program,
}: Props) {
  const host = useRef<HTMLDivElement>(null);
  const [failed, setFailed] = useState(false);
  const active = useRef({ selected, playing, phase, program, onSelect });
  const fit = useRef<() => void>(() => {});
  const invalidateScene = useRef<() => void>(() => {});
  active.current = { selected, playing, phase, program, onSelect };
  useEffect(() => {
    fit.current();
  }, [reset]);
  useEffect(() => {
    invalidateScene.current();
  }, [selected, playing, phase, program]);
  useEffect(() => {
    const el = host.current!;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: "high-performance",
      });
    } catch {
      setFailed(true);
      return;
    }
    setFailed(false);
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    // Camera and highlight changes reuse the same shadow map. Only actual
    // articulated geometry changes require another depth pass.
    renderer.shadowMap.autoUpdate = false;
    renderer.shadowMap.needsUpdate = true;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.setClearColor(0x212121, 0);
    el.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    const reducedMotion = matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;
    const camera = new THREE.PerspectiveCamera(33, 1, 0.2, 10000);
    camera.up.set(0, 0, 1);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !reducedMotion;
    controls.dampingFactor = 0.09;
    controls.maxPolarAngle = Math.PI * 0.49;
    controls.minDistance = 20;
    const pmrem = new THREE.PMREMGenerator(renderer);
    const room = new RoomEnvironment();
    const environment = pmrem.fromScene(room, 0.05);
    scene.environment = environment.texture;
    scene.environmentIntensity = 0.75;
    room.dispose();
    pmrem.dispose();
    scene.add(new THREE.HemisphereLight(0xeaf4ff, 0x56564e, 1.8));
    const key = new THREE.DirectionalLight(0xfff4e6, 3.2);
    key.position.set(-90, -130, 280);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    key.shadow.normalBias = 0.25;
    key.shadow.bias = -0.00012;
    key.shadow.radius = 4;
    scene.add(key);
    const rim = new THREE.DirectionalLight(0xc6ddff, 2.3);
    rim.position.set(110, 120, 130);
    scene.add(rim);
    const fill = new THREE.DirectionalLight(0xffffff, 1.3);
    fill.position.set(100, -220, 40);
    scene.add(fill);
    const group = new THREE.Group();
    scene.add(group);
    const objects = new Map<string, THREE.Object3D>();
    const materials = new Map<string, THREE.MeshStandardMaterial>();
    const shapeByName = new Map(cad?.shapes.map((s) => [s.name, s]));
    const entityById = new Map(project.entities.map((e) => [e.id, e]));
    function makeMaterial(entity: Entity, opacity: number) {
      const type = entity.metadata.material;
      const metal = type === "steel" || entity.geometry?.type === "wire";
      const material = new THREE.MeshPhysicalMaterial({
        color: entity.color ?? "#aebcbd",
        emissiveIntensity: 0,
        metalness: metal ? 0.83 : 0.02,
        roughness: metal
          ? 0.24
          : type === "nylon"
            ? 0.58
            : type === "glue"
              ? 0.25
              : 0.39,
        clearcoat: type === "blue-servo" ? 0.5 : type === "glue" ? 0.6 : 0,
        clearcoatRoughness: 0.32,
        opacity,
        transparent: opacity < 1,
        depthWrite: opacity >= 0.9,
        envMapIntensity: metal ? 1.5 : 0.8,
      });
      materials.set(entity.id, material);
      return material;
    }
    function add(entity: Entity) {
      const g = entity.geometry;
      if (!g || entity.metadata.sceneHidden === true) return;
      const shape = shapeByName.get(g.shapeName ?? "");
      // Mesh-only parts wait for their authoritative kernel result. Never replace
      // the photo reconstruction with a fabricated arrangement of proxy boxes.
      if (g.type === "mesh" && !shape) return;
      let geometry: THREE.BufferGeometry;
      if (shape) {
        geometry = new THREE.BufferGeometry();
        geometry.setAttribute(
          "position",
          new THREE.Float32BufferAttribute(shape.mesh.vertices, 3),
        );
        geometry.setIndex(shape.mesh.triangles);
        if (shape.mesh.normals.length === shape.mesh.vertices.length)
          geometry.setAttribute(
            "normal",
            new THREE.Float32BufferAttribute(shape.mesh.normals, 3),
          );
        else geometry.computeVertexNormals();
        geometry.translate(
          -entity.position[0],
          -entity.position[1],
          -entity.position[2],
        );
      } else if (g.type === "wire" && g.points?.length) {
        const path = new THREE.CurvePath<THREE.Vector3>();
        g.points
          .slice(1)
          .forEach((point, index) =>
            path.add(
              new THREE.LineCurve3(
                new THREE.Vector3(...g.points![index]),
                new THREE.Vector3(...point),
              ),
            ),
          );
        geometry = new THREE.TubeGeometry(
          path,
          Math.max(24, g.points.length * 12),
          g.radius ?? 0.55,
          10,
          false,
        );
      } else if (g.type === "cylinder") {
        geometry = new THREE.CylinderGeometry(
          g.radius ?? 4,
          g.radius ?? 4,
          g.length ?? 8,
          32,
        );
        geometry.rotateX(Math.PI / 2);
      } else geometry = new THREE.BoxGeometry(...(g.size ?? [10, 10, 8]));
      const material = makeMaterial(entity, shape?.opacity ?? 1);
      if (shape?.color) material.color.set(shape.color);
      const object = new THREE.Mesh(geometry, material);
      object.position.set(...entity.position);
      if (entity.rotation) object.rotation.set(...entity.rotation);
      object.castShadow = entity.metadata.material !== "glue";
      object.receiveShadow = true;
      object.userData.entityId = entity.id;
      object.userData.baseRotation = object.rotation.clone();
      object.userData.basePosition = object.position.clone();
      objects.set(entity.id, object);
      group.add(object);
    }
    project.entities.forEach(add);
    // Generic projects may contain an unbound native model. Keep these meshes
    // visible without requiring them to be converted to built-in primitives.
    if (
      cad &&
      !project.entities.some((e) =>
        shapeByName.has(e.geometry?.shapeName ?? ""),
      )
    ) {
      for (const shape of cad.shapes) {
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute(
          "position",
          new THREE.Float32BufferAttribute(shape.mesh.vertices, 3),
        );
        geometry.setIndex(shape.mesh.triangles);
        geometry.computeVertexNormals();
        const mesh = new THREE.Mesh(
          geometry,
          new THREE.MeshStandardMaterial({
            color: shape.color ?? "#80cbc4",
            roughness: 0.4,
            metalness: 0.15,
            opacity: shape.opacity ?? 1,
            transparent: (shape.opacity ?? 1) < 1,
          }),
        );
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        group.add(mesh);
      }
    }
    const bounds = new THREE.Box3().setFromObject(group);
    const center = bounds.isEmpty()
      ? new THREE.Vector3()
      : bounds.getCenter(new THREE.Vector3());
    const span = bounds.isEmpty()
      ? 100
      : Math.max(...bounds.getSize(new THREE.Vector3()).toArray(), 50);
    const floorZ = bounds.isEmpty() ? 0 : bounds.min.z - 0.4;
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(span * 8, span * 8),
      new THREE.ShadowMaterial({ color: 0x000000, opacity: 0.24 }),
    );
    ground.position.z = floorZ;
    ground.receiveShadow = true;
    scene.add(ground);
    const grid = new THREE.GridHelper(
      Math.ceil((span * 2) / 10) * 10,
      Math.min(80, Math.ceil((span * 2) / 10)),
      0x586260,
      0x424a48,
    );
    grid.rotation.x = Math.PI / 2;
    grid.position.z = floorZ - 0.03;
    const gridMaterial = grid.material as THREE.Material;
    gridMaterial.transparent = true;
    gridMaterial.opacity = 0.22;
    gridMaterial.depthWrite = false;
    scene.add(grid);
    const shadowSpan = span * 0.8;
    Object.assign(key.shadow.camera, {
      left: -shadowSpan,
      right: shadowSpan,
      top: shadowSpan,
      bottom: -shadowSpan,
      near: 1,
      far: span * 6,
    });
    key.target.position.copy(center);
    scene.add(key.target);
    key.shadow.camera.updateProjectionMatrix();
    camera.far = span * 40;
    controls.maxDistance = span * 12;
    controls.target.copy(center);
    let frame: number | null = null;
    let disposed = false;
    let lastTime = performance.now();
    const invalidate = () => {
      if (!disposed && frame === null) frame = requestAnimationFrame(animate);
    };
    invalidateScene.current = invalidate;
    controls.addEventListener("change", invalidate);
    const viewDirection = new THREE.Vector3(0.9, -1.6, 0.92).normalize();
    const fitPosition = new THREE.Vector3();
    const fitTarget = center.clone();
    let fitting = false;
    const fitCamera = (instant = false) => {
      const direction = viewDirection;
      const right = new THREE.Vector3()
        .crossVectors(direction, camera.up)
        .normalize();
      const up = new THREE.Vector3().crossVectors(right, direction).normalize();
      let width = 0,
        height = 0,
        depth = 0;
      for (const x of [bounds.min.x, bounds.max.x])
        for (const y of [bounds.min.y, bounds.max.y])
          for (const z of [bounds.min.z, bounds.max.z]) {
            const corner = new THREE.Vector3(x, y, z).sub(center);
            width = Math.max(width, Math.abs(corner.dot(right)));
            height = Math.max(height, Math.abs(corner.dot(up)));
            depth = Math.max(depth, Math.abs(corner.dot(direction)));
          }
      const tan = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
      const distance = bounds.isEmpty()
        ? 200
        : Math.max(width / (tan * camera.aspect), height / tan) * 1.12 +
          depth * 0.65;
      fitPosition.copy(center).addScaledVector(direction, distance);
      fitTarget.copy(center);
      if (instant || reducedMotion) {
        camera.position.copy(fitPosition);
        controls.target.copy(fitTarget);
        fitting = false;
      } else fitting = true;
      camera.updateProjectionMatrix();
    };
    fit.current = () => {
      fitCamera();
      invalidate();
    };
    controls.addEventListener("start", () => {
      fitting = false;
    });
    let firstSize = true;
    const observer = new ResizeObserver(() => {
      const w = el.clientWidth,
        h = el.clientHeight;
      if (!w || !h) return;
      renderer.setSize(w, h);
      const previousAspect = camera.aspect;
      camera.aspect = w / h;
      if (firstSize) {
        fitCamera(true);
        firstSize = false;
      } else if (Math.abs(previousAspect - camera.aspect) > 0.08) fitCamera();
      camera.updateProjectionMatrix();
      invalidate();
    });
    observer.observe(el);
    const raycaster = new THREE.Raycaster();
    // Thin wire remains selectable at normal assembly framing.
    const pointer = new THREE.Vector2();
    let down = [0, 0];
    const start = (e: PointerEvent) => {
      down = [e.clientX, e.clientY];
    };
    const pick = (e: PointerEvent) => {
      if (Math.hypot(e.clientX - down[0], e.clientY - down[1]) > 5) return;
      const rect = el.getBoundingClientRect();
      pointer.set(
        ((e.clientX - rect.left) / rect.width) * 2 - 1,
        (-(e.clientY - rect.top) / rect.height) * 2 + 1,
      );
      raycaster.setFromCamera(pointer, camera);
      const hit = raycaster.intersectObjects([...objects.values()], false)[0];
      active.current.onSelect(hit?.object.userData.entityId ?? null);
    };
    renderer.domElement.addEventListener("pointerdown", start);
    renderer.domElement.addEventListener("pointerup", pick);
    let elapsed = 0;
    const jointRotations = new Map<string, number>();
    const animate = (now: number) => {
      frame = null;
      const delta = Math.min(Math.max((now - lastTime) / 1000, 1 / 240), 0.1);
      lastTime = now;
      let highlightsSettling = false;
      const current = active.current;
      if (current.playing) elapsed += delta;
      for (const [id, material] of materials) {
        const entity = entityById.get(id);
        const selectedPart =
          id === current.selected || entity?.parentId === current.selected;
        const linked = entity?.metadata.driver === current.selected;
        material.emissive.set(selectedPart ? "#80cbc4" : "#284b46");
        const intensity = selectedPart ? 0.25 : linked ? 0.1 : 0;
        if (
          reducedMotion ||
          Math.abs(material.emissiveIntensity - intensity) < 0.0005
        ) {
          material.emissiveIntensity = intensity;
        } else {
          material.emissiveIntensity = THREE.MathUtils.damp(
            material.emissiveIntensity,
            intensity,
            16,
            delta,
          );
          highlightsSettling = true;
        }
      }
      const motion = project.motion;
      if (motion) {
        let phaseIndex = current.phase,
          progress = 1;
        if (current.playing) {
          const total = motion.phases.reduce(
            (s, p) => s + p.durationMs + p.settleMs,
            0,
          );
          let time = (elapsed * 1000) % total;
          phaseIndex = 0;
          for (let i = 0; i < motion.phases.length; i++) {
            const p = motion.phases[i];
            if (time < p.durationMs + p.settleMs) {
              phaseIndex = i;
              progress = Math.min(1, time / Math.max(p.durationMs, 1));
              break;
            }
            time -= p.durationMs + p.settleMs;
          }
        }
        const targetPhase = motion.phases[Math.max(0, phaseIndex)];
        for (const joint of motion.joints) {
          const target =
            targetPhase?.targets[joint.entityId] ??
            targetPhase?.targets[joint.channel ?? ""] ??
            joint.centerUs;
          const previousPhase =
            motion.phases[
              (phaseIndex - 1 + motion.phases.length) % motion.phases.length
            ];
          const previous =
            previousPhase?.targets[joint.entityId] ??
            previousPhase?.targets[joint.channel ?? ""] ??
            joint.centerUs;
          const pulse = current.program
            ? (current.program.targets[joint.entityId] ?? joint.centerUs)
            : current.playing
              ? previous + (target - previous) * progress
              : target;
          const angle =
            (((pulse - joint.centerUs) / (joint.pulsePerDegree ?? 10)) *
              Math.PI) /
            180;
          const rotation =
            current.program || current.playing || current.phase >= 0
              ? angle
              : 0;
          if (jointRotations.get(joint.entityId) === rotation) continue;
          jointRotations.set(joint.entityId, rotation);
          renderer.shadowMap.needsUpdate = true;
          const axis = new THREE.Vector3(...joint.axis).normalize();
          const driver = entityById.get(joint.entityId);
          const authoredPivot = driver?.metadata.jointPivot;
          const pivot = new THREE.Vector3(
            ...(Array.isArray(authoredPivot) && authoredPivot.length === 3
              ? (authoredPivot as [number, number, number])
              : (driver?.position ?? [0, 0, 0])),
          );
          for (const id of joint.drivenEntityIds ?? [joint.entityId]) {
            const object = objects.get(id);
            if (!object) continue;
            object.rotation.copy(object.userData.baseRotation);
            object.position
              .copy(object.userData.basePosition)
              .sub(pivot)
              .applyAxisAngle(axis, rotation)
              .add(pivot);
            object.rotateOnAxis(axis, rotation);
          }
        }
      }
      if (fitting) {
        const factor = 1 - Math.exp(-delta * 9);
        camera.position.lerp(fitPosition, factor);
        controls.target.lerp(fitTarget, factor);
        if (camera.position.distanceToSquared(fitPosition) < 0.01)
          fitting = false;
      }
      const orbitChanged = controls.update();
      renderer.render(scene, camera);
      // OrbitControls emits changes while damping. Once camera, selection and
      // motion settle, release RAF entirely until the next user/state event.
      if (current.playing || fitting || highlightsSettling || orbitChanged)
        invalidate();
    };
    invalidate();
    return () => {
      disposed = true;
      fit.current = () => {};
      invalidateScene.current = () => {};
      if (frame !== null) cancelAnimationFrame(frame);
      observer.disconnect();
      controls.removeEventListener("change", invalidate);
      controls.dispose();
      environment.dispose();
      renderer.domElement.removeEventListener("pointerdown", start);
      renderer.domElement.removeEventListener("pointerup", pick);
      scene.traverse((object) => {
        if (
          object instanceof THREE.Mesh ||
          object instanceof THREE.LineSegments
        ) {
          object.geometry.dispose();
          (Array.isArray(object.material)
            ? object.material
            : [object.material]
          ).forEach((m) => m.dispose());
        }
      });
      renderer.dispose();
      el.removeChild(renderer.domElement);
    };
  }, [project, cad]);
  return (
    <div
      className="scene"
      ref={host}
      aria-label="Interactive assembly. Drag to orbit, shift drag to pan, scroll to zoom."
    >
      {failed && (
        <div className="center-state">
          3D rendering is unavailable in this browser. Use the object tree or
          native source view.
        </div>
      )}
    </div>
  );
}
