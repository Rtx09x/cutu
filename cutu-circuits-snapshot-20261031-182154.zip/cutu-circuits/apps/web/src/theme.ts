import { getAppTheme, resolveTheme } from "@cutucircuits/ui";
import { materialSurfaceColors } from "@cutucircuits/ui/themes/foundation";
export function applyTheme() {
  const root = document.documentElement;
  root.dataset.theme = "material";
  root.dataset.colorMode = "dark";
  root.style.colorScheme = "dark";
  for (const [key, value] of Object.entries({
    ...resolveTheme(getAppTheme("material").dark),
    ...materialSurfaceColors,
  }))
    root.style.setProperty(`--theme-${key}`, value);
}
