import { useEffect, useState } from "react";
import type {
  Project,
  CadResult,
  FileSnapshot,
  EngineResult,
} from "@cutucircuits/core";
import { api } from "./api";
const compiledModels = new Map<string, Promise<CadResult>>();
/** Native source hashes keep reused assembly meshes coherent with editor and Codex saves. */
export function useAssemblyCad(project: Project | undefined, revision: number) {
  const [cad, setCad] = useState<CadResult>(),
    [loading, setLoading] = useState(false),
    [error, setError] = useState("");
  const asset = project?.assets.find((a) => a.kind === "cad");
  useEffect(() => {
    let cancelled = false;
    setCad(undefined);
    setError("");
    if (!project || !asset) {
      setLoading(false);
      return;
    }
    const base = `/projects/${project.id}`;
    const path = asset.path;
    setLoading(true);
    async function load() {
      const snapshot = await api<FileSnapshot>(
        `${base}/files?path=${encodeURIComponent(path)}`,
      );
      if (cancelled) return;
      const key = `${base}:${path}:${snapshot.sha256}`;
      let result = compiledModels.get(key);
      if (!result) {
        result = api<EngineResult>(`${base}/compile`, { path }).then(
          (result) => {
            if (result.kind !== "cad")
              throw new Error("The native model did not return CAD geometry.");
            if (result.sourceSha256 !== snapshot.sha256)
              throw new Error(
                "The model changed during compilation. Compile again to refresh.",
              );
            return result;
          },
        );
        compiledModels.set(key, result);
        result.catch(() => compiledModels.delete(key));
        while (compiledModels.size > 8)
          compiledModels.delete(compiledModels.keys().next().value!);
      }
      const model = await result;
      if (!cancelled) setCad(model);
    }
    void load()
      .catch((e) => {
        if (!cancelled) setError(e instanceof Error ? e.message : String(e));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [project?.id, asset?.path, revision]);
  return { cad, loading, error };
}
